package dsproject;

import java.util.Scanner;

class Patient {
    int patientId;
    String name;
    String reasonForVisit;
    int priority; 
    Patient next;
    Patient prev;

    public Patient(int patientId, String name, String reasonForVisit, int priority) {
        this.patientId = patientId;
        this.name = name;
        this.reasonForVisit = reasonForVisit;
        this.priority = priority;
        this.next = null;
        this.prev = null;
    }

    @Override
    public String toString() {
        return "Patient ID: " + patientId + ", Name: " + name + ", Reason: " + reasonForVisit + ", Priority: " + priority;
    }
}

class PatientManagementSystem {
    private Patient head; 
    private Patient tail; 
    private Patient historyHead; 

    public PatientManagementSystem() {
        this.head = null;
        this.tail = null;
        this.historyHead = null;
    }

    
    public void addPatient(int patientId, String name, String reasonForVisit, int priority) {
        Patient newPatient = new Patient(patientId, name, reasonForVisit, priority);
        if (head == null) {
            head = tail = newPatient;
        } else {
            tail.next = newPatient;
            newPatient.prev = tail;
            tail = newPatient;
        }
        System.out.println("Patient added to waiting list: " + newPatient);
    }

    
    public void prioritizePatient(int patientId) {
        Patient current = head;
        while (current != null && current.patientId != patientId) {
            current = current.next;
        }

        if (current == null) {
            System.out.println("Patient with ID " + patientId + " not found in the waiting list.");
            return;
        }

        if (current == head) {
            System.out.println("Patient " + current.name + " is already at the front of the list.");
            return;
        }

        // إزالة المريض من موقعه الحالي
        if (current.prev != null) {
            current.prev.next = current.next;
        }
        if (current.next != null) {
            current.next.prev = current.prev;
        }
        if (current == tail) {
            tail = current.prev;
        }

        
        current.next = head;
        head.prev = current;
        head = current;
        current.prev = null;

        System.out.println("Patient " + current.name + " has been prioritized to the front of the list.");
    }

    
    public void attendPatient() {
        if (head == null) {
            System.out.println("No patients in the waiting list.");
            return;
        }

        Patient attendedPatient = head;
        head = head.next;
        if (head != null) {
            head.prev = null;
        } else {
            tail = null; 
        }

        
        attendedPatient.next = historyHead;
        if (historyHead != null) {
            historyHead.prev = attendedPatient;
        }
        historyHead = attendedPatient;

        System.out.println("Patient attended and moved to history: " + attendedPatient);
    }

    
    public void viewWaitingList() {
        if (head == null) {
            System.out.println("No patients in the waiting list.");
            return;
        }

        System.out.println("Current Waiting List:");
        Patient current = head;
        while (current != null) {
            System.out.println(current);
            current = current.next;
        }
    }

    
    public void viewPatientHistory() {
        if (historyHead == null) {
            System.out.println("No patients in the history.");
            return;
        }

        System.out.println("Patient History:");
        Patient current = historyHead;
        while (current != null) {
            System.out.println(current);
            current = current.next;
        }
    }

    
    public void findPatientById(int patientId) {
        Patient current = head;
        while (current != null) {
            if (current.patientId == patientId) {
                System.out.println("Patient found: " + current);
                return;
            }
            current = current.next;
        }
        System.out.println("Patient with ID " + patientId + " not found in the waiting list.");
    }

   
    public void updatePriorities() {
        Patient current = head;
        while (current != null) {
            if (current.priority > 1) { 
                current.priority--; 
            }
            current = current.next;
        }
        System.out.println("Patient priorities have been dynamically updated based on waiting time.");
    }

    public void updatePatientData(int patientId, String newName, String newReasonForVisit, int newPriority) {
        Patient current = head;
        while (current != null) {
            if (current.patientId == patientId) {
                current.name = newName != null ? newName : current.name;
                current.reasonForVisit = newReasonForVisit != null ? newReasonForVisit : current.reasonForVisit;
                current.priority = newPriority > 0 ? newPriority : current.priority;

                System.out.println("Patient data updated: " + current);
                return;
            }
            current = current.next;
        }
        System.out.println("Patient with ID " + patientId + " not found in the waiting list.");
    }
}

class PriorityUpdater extends Thread {
    private PatientManagementSystem system;

    public PriorityUpdater(PatientManagementSystem system) {
        this.system = system;
    }

    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(30000); 
                system.updatePriorities();
            } catch (InterruptedException e) {
                System.out.println("Priority updating thread interrupted.");
            }
        }
    }
}

public class DSproject {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PatientManagementSystem system = new PatientManagementSystem();
        PriorityUpdater updater = new PriorityUpdater(system);
        updater.start(); 

        while (true) {
            System.out.println("\n--- Patient Management System ---");
            System.out.println("1. Add Patient");
            System.out.println("2. Prioritize Patient");
            System.out.println("3. Attend Patient");
            System.out.println("4. View Waiting List");
            System.out.println("5. View Patient History");
            System.out.println("6. Find Patient by ID");
            System.out.println("7. Update Patient Data");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Patient ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter Patient Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Reason for Visit: ");
                    String reason = scanner.nextLine();
                    System.out.print("Enter Priority (1: High, 2: Medium, 3: Low): ");
                    int priority = scanner.nextInt();
                    system.addPatient(id, name, reason, priority);
                    break;
                
                case 2:
                    System.out.print("Enter Patient ID to prioritize: ");
                    int prioritizeId = scanner.nextInt();
                    system.prioritizePatient(prioritizeId);
                    break;
                
                case 3:
                    system.attendPatient();
                    break;
                
                case 4:
                    system.viewWaitingList();
                    break;
                
                case 5:
                    system.viewPatientHistory();
                    break;

                case 6:
                    System.out.print("Enter Patient ID to find: ");
                    int searchId = scanner.nextInt();
                    system.findPatientById(searchId);
                    break;
                
                case 7:
                    System.out.print("Enter Patient ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter new Name (or press Enter to keep the same): ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new Reason for Visit (or press Enter to keep the same): ");
                    String newReason = scanner.nextLine();
                    System.out.print("Enter new Priority (1: High, 2: Medium, 3: Low, or press Enter to keep the same): ");
                    int newPriority = scanner.nextInt();
                    
                    system.updatePatientData(updateId, newName.isEmpty() ? null : newName, newReason.isEmpty() ? null : newReason, newPriority);
                    break;

                case 8:
                    System.out.println("Exiting the system.");
                    scanner.close();
                    return;
                
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
    }
}
